package com.example.myapplication.Storage;

import com.example.myapplication.Model.Item;

import java.util.ArrayList;

public class itemStorage {
    //ArrayList<Item> items = new ArrayList<>();
}
